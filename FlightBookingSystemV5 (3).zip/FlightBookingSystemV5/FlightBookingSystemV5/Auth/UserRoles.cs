﻿namespace FlightBookingSystemV5.Auth
{
    public static class UserRoles
    {
        public const string Airline = "Airline";
        public const string User = "User";
        public const string Admin = "Admin";
    }
}
