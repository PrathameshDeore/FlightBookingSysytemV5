import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  startLoc: string = "";
  endLoc: string = "";
  startDate: string = "";
  currentDate: string = new Date().toISOString().slice(0, 10);
  onSubmit() {
    if (this.startLoc.trim() == "" || this.endLoc.trim() == "" || this.startDate.trim() == "") {
      alert("Please Enter All The Details!");
    }
    else {
      console.log(this.startLoc + " " + this.endLoc + " " + this.startDate);
    }
  }
}
