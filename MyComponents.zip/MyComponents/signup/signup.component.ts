import { Component } from '@angular/core';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  name: string = "";
  email: string = "";
  password: string = "";
  cPassword: string = "";

  onSubmit() {
    let mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (this.name.trim() == "" || this.email.trim() == "" || this.password.trim() == "" || this.cPassword.trim() == "") {
      alert("Please Enter All The Details!");
    }
    else if (!this.email.trim().match(mailformat)) {
      alert("Please Enter a Valid Email ID!");
    }
    else if (this.password.trim() != this.cPassword.trim()) {
      alert("Password And Confirm Password Doesn't Match!");
    }
    else {
      console.log(this.name + " " + this.email + " " + this.password + " " + this.cPassword);
    }
  }
}
